package com.belajar.andro.fragmentwithrecyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {
    TextView tvDetail, tvNameDetail;
    ImageView ivPhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        ivPhoto = findViewById(R.id.detail_image);
        tvNameDetail = findViewById(R.id.detail_advantage);
        tvDetail = findViewById(R.id.detail_advantage);

        getIncomingExtra();
    }

    private void getIncomingExtra() {
        if (getIntent().hasExtra("photo") && getIntent().hasExtra("nama") && getIntent().hasExtra("detail")){
            int photoVegetable = getIntent().getIntExtra("photo", 0);
            String nameVegetable = getIntent().getStringExtra("nama");
            String detailVegetable = getIntent().getStringExtra("detail");

            setDataActivity(photoVegetable, nameVegetable, detailVegetable);
        }
    }

    private void setDataActivity(int photoVegetable, String nameVegetable, String detailVegetable) {
        Glide.with(this).asBitmap().load(photoVegetable).into(ivPhoto);
        tvNameDetail.setText(nameVegetable);
        tvDetail.setText(detailVegetable);
    }
}