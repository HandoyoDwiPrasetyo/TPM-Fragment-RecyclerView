package com.belajar.andro.fragmentwithrecyclerview;

public class ListGalleryModel {
    private String VegetableName;
    private int vegetablePhoto;
    private String vegetableDetail;

    public String getVegetableName() {
        return VegetableName;
    }

    public void setVegetableName(String vegetableName) {
        VegetableName = vegetableName;
    }

    public int getVegetablePhoto() {
        return vegetablePhoto;
    }

    public void setVegetablePhoto(int vegetablePhoto) {
        this.vegetablePhoto = vegetablePhoto;
    }

    public String getVegetableDetail() {
        return vegetableDetail;
    }

    public void setVegetableDetail(String vegetableDetail) {
        this.vegetableDetail = vegetableDetail;
    }
}
