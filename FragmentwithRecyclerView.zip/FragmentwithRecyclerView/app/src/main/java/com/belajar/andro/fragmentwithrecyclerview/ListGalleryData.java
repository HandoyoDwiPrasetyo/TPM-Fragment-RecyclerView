package com.belajar.andro.fragmentwithrecyclerview;

import java.util.ArrayList;

public class ListGalleryData {
    private static String[] title = new String[]{"Bayam","Sawi","Kangkung",
            "Timun","Seledri","Daun Singkong","Pare","Brokoli","Pak Choy","Buncis"};

    private static int[] photo = new
            int[]{R.drawable.bayam,R.drawable.sawi,R.drawable.kankung,
            R.drawable.timun,R.drawable.seledri,R.drawable.daunsingkong,
            R.drawable.pare,R.drawable.brokoli,R.drawable.pakchoy,R.drawable.buncis};

    private static String[] detail = new String[]{
            "Bayam memiliki serat yang tinggi, selain itu bayam marupakan sumber zat besi yang baik untuk darah. Bayam juga mengandung lutein yang berfungsi menjaga kesehatan mata kita. Vitamin dalam bayam juga bermacam, ada vitamin A, C, K, dan juga folat.",
            "Kandungan mineral dan vitamin dalam sawi cukup tinggi. Kandungan vitamin C dan E, serta karoten dan glukosinolat dalam sawi berfungsi sebagai antioksidan yang baik untuk tubuh kita. Dalam sawi juga ada kalsium, magnesium dan asam folat yang sangat baik untuk tulang. Kandungan serat sawi juga tinggi, sehingga sangat baik untuk pencernaan.",
            "Kandungan di dalam kangkung sangat banyak seperti vitamin A, vitamin C yang cukup tinggi walaupun nggak sebanyak pada bayam dan singkong. Vitamin B kompleks yang ada pada kangkung dapat meningkatkan hormon yang dapat menciptakan suasana nyaman, mungkin ini yang bikin kita jadi ngantuk. Mineral juga ditemukan dalam kangkung, meliputi kalium, fosfor dan kalsium. Selain itu, ternyata ekstrak dari sayuran hijau yang satu ini dapat membantu menghambat penyerapan gula, sehingga cocok bagi penderita diabetes.",
            "Timun sering kita gunakan untuk lalapan. Dalam timun, vitamin C nya cukup banyak, folat yang berfungsi mengurangi resiko penyakit jantung dan depresi pun juga lumayan banyak. Selain itu, ada juga mangan, serat, magnesium, klorofil dan lutein. Selain timun dapat menjaga kesehatan penceernaan, dia juga dapat menyegarkan tubuh karena kandungan airnya yang banyak.",
            "Seledri adalah sumber mineral, yaitu kalsium, zat besi, kalium. Selain mineral, seledri juga mengandung vitamin A dan C. Komponen aktif bernama phthalides dalam seledri berguna untuk menurunkan tekanan darah. Seledri juga memiliki komponen aktif lain yaitu coumarin dan acetylenics yang bisa mencegah perkembangan sel kanker.",
            "Kandungan protein dan zat besi pada daun singkong muda cukup tinggi. Selain itu terdapat juga vitamin A dan C. Jika dibandingkan dengan bayam, daun singkong memiliki kandungan zat besi yang setara. Bahkan, kandungan protein daun singkong empat kali lipat dan vitamin A dua kali lipat dari bayam.",
            "Pare ini merupakan sayuran yang rasanya pahit, tapi penggemarnya juga lumayan banyak. Pare mengandung serat yang tinggi, selain itu juga ada kalsium, kalium, zat besi, vitamin C dan vitamin A. Manfaat dari pare ini sangat banyak, bisa menurunkan kadar gula dalam darah, menurunkan kolesterol, dan menurunkan tekanan darah. Komponen aktif dalam pare dapat meningkatkan imunitas tubuh.",
            "Brokoli ternyata berasal dari Italia, kandungan vitamin C di dalamnya sangat baik untuk tubuh kita. Nggak cuma kaya serat, vitamin, dan mineral saja, tapi brokoli juga mengandung antioksidan yaitu sulforaphane dan lutein yang baik untuk menurunkan risiko kanker. Brokoli juga dipercaya bermanfaat untuk kesehatan jantung.",
            "Pak choy atau bok choy sering disebut sendok sup, mungkin karena bentuk daunnya yang mirip seperti sendok sup. Sayuran ini termasuk jenis kubis-kubisan yang kaya vitamin A, C, D dan folat. Nggak cuma itu, pak coy ternyata juga banyak mengandung kalium yang baik untuk keseimbangan cairan di dalam tubuh dan untuk kesehatan jantung. Kandungan glucosinolates dalam pak choy berfungsi sebagai antioksidan  yang mampu mencegah kanker prostat dan payudara.",
            "Buncis merupakan sayuran banyak mengandung vitamin A, C, dan K, serta mengandung folat, zat besi, kalium, mangan, dan serat. Buncis juga baik untuk kesehatan jantung karena mengandung senyawa antioksidan. Serat yang terdapat pada buncis diperkirakan dapat menurunkan risiko diabetes tipe 2 dan reaksi inflamasi yang lain."
    };

    public static ArrayList<ListGalleryModel> getListData(){
        ListGalleryModel listGalleryModel  = null;
        ArrayList<ListGalleryModel> list = new ArrayList<>();
        for (int i = 0; i < title.length; i++){
            listGalleryModel = new ListGalleryModel();
            listGalleryModel.setVegetablePhoto(photo[i]);
            listGalleryModel.setVegetableName(title[i]);
            listGalleryModel.setVegetableDetail(detail[i]);
            list.add(listGalleryModel);
        }
        return list;
    }

}
